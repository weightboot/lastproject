-- 운영상태 생성
create table managestatus
(
	ID int primary key,
	name varchar(10)
);
insert into managestatus (ID, name) values (0, '휴장');
insert into managestatus (ID, name) values (1, '운영');


-- 캠핑 정보. 기본 meta
create table campinfo
(
	id int primary key				        -- 콘텐츠 ID 
	, facltNm varchar(50) not null	  		-- 야영장명
	, lineIntro varchar(500) 				-- 한줄 소개
	, intro varchar(5000)					-- 소개
	, manageSttus int 						-- 운영상태. 관리상태. 0: 휴장, 1: 운영
	, featureNm varchar(500)				-- 특징
	, doNm varchar(10)						-- 도
	, sigunguNm varchar(20)					-- 시군구
	, addr1 varchar(100)					-- 주소
	, direction varchar(1000)				-- 오시는 길
	, tel varchar(20)						-- 전화
	, homepage varchar(300)					-- 홈페이지
	, resveUrl varchar(1000)			    -- 예약 홈페이지
	, gnrlSiteCo int 						-- 주요시설 일반 야영장
	, autoSiteCo int						-- 주요시설 자동차야영장
	, glampSiteCo int						-- 주요시설 글램핑
	, caravSiteCo int						-- 주요시설 카라반
	, indvdlCaravSiteCo int					-- 주요시설 개인 카라반
	, eqpmnLendCl varchar(50)				-- 캠핑장비대여
	, animalCmgCl varchar(50)				-- 애완동물출입
	, firstImageUrl varchar(150)			-- 대표 이미지
	, createdtime timestamp				    -- 등록일.  
	, modifiedtime timestamp				-- 수정일
	, constraint FK_campinfo_manageSttus foreign KEY(manageSttus) references "managestatus" (ID) 
);


-- induty 생성
create table induty
(
	id int generated always as identity primary key
	, name varchar(30)
);
insert into induty(name) values ('일반야영장');
insert into induty(name) values ('자동차야영장');
insert into induty(name) values ('글램핑');
insert into induty(name) values ('카라반');


-- theme 생성
create table theme
(
	id int generated always as identity primary key
	, name varchar(30)
);
insert into theme(name) values ('가을단풍명소');
insert into theme(name) values ('걷기길');
insert into theme(name) values ('겨울눈꽃명소');
insert into theme(name) values ('낚시');
insert into theme(name) values ('봄꽃여행');
insert into theme(name) values ('수상레저');
insert into theme(name) values ('스키');
insert into theme(name) values ('액티비티');
insert into theme(name) values ('여름물놀이');
insert into theme(name) values ('일몰명소');
insert into theme(name) values ('일출명소');
insert into theme(name) values ('항공레저');


-- facility 테이블 생성
create table facility
(
  camp_id int primary key,      -- camp ID
  toiletco int default 0,   	-- 화장실 개수
  swrmco int default 0,     	-- 샤워실 개수
  wtrplco int default 0,    	-- 개수대 개수
  brazierco varchar(20)     	-- 화로대 개수
); 
