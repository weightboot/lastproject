-- bridge 관련 필드는 빼서 같은 ID가 여러 번 나오는 일이 없도록 한 view
-- 이제 이거랑 bridge 담은 아래 뷰들이랑 조인 예정
create or replace view v_campinfo3
as 
select
	I.id as ID
	, facltNm
	, lineIntro
	, intro
	, MS.name as managestatus		-- 운영 상태.	
	, doNm
	, sigunguNm
	, addr1
	, direction
	, tel
	, homepage
	, resveUrl
	, gnrlSiteCo
	, autoSiteCo
	, glampSiteCo
	, caravSiteCo
	, indvdlCaravSiteCo
	, eqpmnLendCl
	, animalCmgCl
	, firstImageUrl
	, createdtime
	, modifiedtime
	, G.geom as geom
from
	campInfo I
	, campGeom G
	, managestatus MS	
where 	
	I.ID = G.contentID             -- 요 부분 수정 contentID
	and I.managesttus = MS.ID 
;

-- induty와 theme 모두 찾아내는 view 만드는 sql
create or replace view v_campinfo_induty_theme
as 
select
	I.id as camp_id
	, max(case when induty.id = 1 then 1 else 0 end) as induty01
	, max(case when induty.id = 2 then 1 else 0 end) as induty02
	, max(case when induty.id = 3 then 1 else 0 end) as induty03
	, max(case when induty.id = 4 then 1 else 0 end) as induty04
	, max(case when theme.id = 1 then 1 else 0 end) as theme01
	, max(case when theme.id = 2 then 1 else 0 end) as theme02
	, max(case when theme.id = 3 then 1 else 0 end) as theme03
	, max(case when theme.id = 4 then 1 else 0 end) as theme04
	, max(case when theme.id = 5 then 1 else 0 end) as theme05
	, max(case when theme.id = 6 then 1 else 0 end) as theme06
	, max(case when theme.id = 7 then 1 else 0 end) as theme07
	, max(case when theme.id = 8 then 1 else 0 end) as theme08
	, max(case when theme.id = 9 then 1 else 0 end) as theme09
	, max(case when theme.id = 10 then 1 else 0 end) as theme10
	, max(case when theme.id = 11 then 1 else 0 end) as theme11
	, max(case when theme.id = 12 then 1 else 0 end) as theme12	
from
	campInfo I
	, campGeom G
	, managestatus MS
	, br_campinfo_induty
	, br_campinfo_theme
	, induty
	, theme
where 	
	I.ID = G.contentID             -- 요 부분 수정 contentID
	and I.managesttus = MS.ID 
	and br_campinfo_induty.induty_id = induty.id
	and br_campinfo_theme.theme_id = theme.id
	and br_campinfo_induty.camp_id = I.id
	and br_campinfo_theme.camp_id = I.id
group by 	
	I.ID;


-- bridge 뷰들과의 조인, facility join(이걸로 레이어에서 사용)	
-- outer join을 해서 induty나 theme가 아예 없는 경우에도 camp 메타 정보는 나오도록
create or replace view v_campinfo7
as select 
	C.id as ID
	, facltNm
	, lineIntro
	, intro
	, managestatus		 -- 운영 상태
    , featurenm          -- 삭제
	, doNm
	, sigunguNm
	, addr1
	, direction
	, tel
	, homepage
	, resveUrl
	, gnrlSiteCo
	, autoSiteCo
	, glampSiteCo
	, caravSiteCo
	, indvdlCaravSiteCo
	, f.toiletCo
	, f.swrmCo
	, f.wtrplCo
	, f.brazierCo
	, eqpmnLendCl
	, animalCmgCl
	, firstImageUrl
	, createdtime
	, modifiedtime
	, COALESCE(induty01, 0) as induty01		-- 일반야영장
	, COALESCE(induty02, 0) as induty02		-- 자동차야영장
	, COALESCE(induty03, 0) as induty03		-- 글램핑
	, COALESCE(induty04, 0) as induty04		-- 카라반
	, COALESCE(theme01, 0) as theme01		-- 가을단풍명소
	, COALESCE(theme02, 0) as theme02		-- 걷기길
	, COALESCE(theme03, 0) as theme03		-- 겨울눈꽃명소
	, COALESCE(theme04, 0) as theme04		-- 낚시
	, COALESCE(theme05, 0) as theme05		-- 봄꽃여행
	, COALESCE(theme06, 0) as theme06		-- 수상레저
	, COALESCE(theme07, 0) as theme07		-- 스키
	, COALESCE(theme08, 0) as theme08		-- 액티비티
	, COALESCE(theme09, 0) as theme09		-- 여름물놀이
	, COALESCE(theme10, 0) as theme10		-- 일몰명소
	, COALESCE(theme11, 0) as theme11		-- 일출명소
	, COALESCE(theme12, 0) as theme12		-- 항공레저
	, geom
from
	v_campinfo3 C
left join 
	v_campinfo_induty_theme B
on
	C.ID = B.camp_id
left join 
	facility F
on
	c.id = f.camp_id	
;

