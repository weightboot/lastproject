// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

var wfsLayer;
var wfsSource;


// CQL 필터 만드는 함수 추가
function makeFilter(method)
{
    let filter="";

    if ('dong01' == method)
      filter ="address like '%대치동%'";

    else if ('dong02' == method)
      filter ="address like '%도곡동%'";

      else if ('dong03' == method)
      filter ="address like '%삼성동%'";

      else if ('dong04' == method)
      filter ="address like '%압구정동%'";

      else if ('dong05' == method)
      filter ="address like '%청담동%'";

      else if ('place01' == method)
      filter ="place = '시군구내'";

      else if ('place02' == method)
      filter ="place = '시도내'";

      else if ('place03' == method)
      filter ="place = '읍면동내'";


    return filter;
}
function makeWFSSource(method)
{
  wfsSource = new VectorSource
  (
    {
      format: new GeoJSON(),
      url: encodeURI(g_url + "/geoserver/cadaWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
            "&typeName=cadaWS:v_cadajijuk&outputFormat=application/json&CQL_FILTER=" + makeFilter(method))
    }
  );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");


wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(17, 30, 108, 1.0)',
      width: 0.8
    }),
    fill: new Fill({
      color: 'rgba(100, 149, 237, 0.4)'
    })
  })

  });


  const osmLayer = new TileLayer({
    source: new OSM()
  });

  const map = new Map
    ({
      // target: document.getElementById('map'),
      target: 'map',
      layers: [osmLayer, wfsLayer],
      view: new View
        ({
          // 지도 중심점 설정
          center: [14145233, 4508571],
          // 지도 확대 레벨 설정
          zoom: 13
        })
    });

    document.getElementById('dong01').onclick = ()=>
      {
        console.log('dong01 clicked');
        makeWFSSource('dong01');
      }

      document.getElementById('dong02').onclick = ()=>
        {
          console.log('dong02 clicked');
          makeWFSSource('dong02');
        }

        document.getElementById('dong03').onclick = ()=>
        {
          console.log('dong03 clicked');
          makeWFSSource('dong03');
        }

        document.getElementById('dong04').onclick = ()=>
        {
          console.log('dong04 clicked');
          makeWFSSource('dong04');
        }

        document.getElementById('dong05').onclick = ()=>
        {
          console.log('dong05 clicked');
          makeWFSSource('dong05');
        }

        document.getElementById('place01').onclick = ()=>
        {
          console.log('place01 clicked');
          makeWFSSource('place01');
        }

        document.getElementById('place02').onclick = ()=>
        {
          console.log('place02 clicked');
          makeWFSSource('place02');
        }

        document.getElementById('place03').onclick = ()=>
        {
          console.log('place03 clicked');
          makeWFSSource('place03');
        }