# Bridge 테이블 생성
## BridgeInDuty 불러와서 텍스트 숫자로 변환

BridgeInDuty = pd.read_csv("BridgeInDuty.csv", header=None)         
map_manage={'일반야영장':1, '자동차야영장':2, '글램핑':3, '카라반':4}
col=[1]
BridgeInDuty[col] = BridgeInDuty[col].applymap(map_manage.get)
BridgeInDuty.to_csv('BridgeInDuty.csv', index=False, header=['contentid', 'induty']) 


## BridgeInDuty 불러와서 텍스트 숫자로 변환

BridgeTheme = pd.read_csv("BridgeTheme.csv", header=None)         
map_manage={'가을단풍명소':1, '걷기길':2, '겨울눈꽃명소':3, '낚시':4, '봄꽃여행':5, '수상레저':6, '스키':7, '액티비티':8, '여름물놀이':9, '일몰명소':10, '일출명소':11, '항공레저':12}
col=[1]
BridgeTheme[col] = BridgeTheme[col].applymap(map_manage.get)
BridgeTheme.to_csv('BridgeTheme.csv', index=False, header=['contentid', 'theme']) 