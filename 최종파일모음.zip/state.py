import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline

camping = pd.read_csv("campInfo.csv")
camping.info()
print('캠핑장 분포 현황:\n', camping['doNm'].value_counts())
print('캠핑장 운영 현황:\n', camping['manageSttus'].value_counts())

# applymap: 요소별로 함수를 적용하는 메서드  
map_manage = {'휴장':'rest', '운영':'run'}
col = ['manageSttus']
camping[col] = camping[col].applymap(map_manage.get)
print('캠핑장 운영 현황:\n', camping['manageSttus'].value_counts())
print('캠핑장 분포 현황:\n', camping['animalCmgCl'].value_counts())

camping.groupby(['animalCmgCl', 'manageSttus'])['manageSttus'].count()
map_animal = {'가능':'able',  '가능(소형견)':'able(small dog)', '불가능':'disable'}
col = ['animalCmgCl']
camping[col] = camping[col].applymap(map_animal.get)
print('애완동물 동반 여부:\n', camping['animalCmgCl'].value_counts())

ax = sns.countplot(x='animalCmgCl', hue = 'manageSttus', data=camping)
for p in ax.patches:
    height = p.get_height()
    ax.text(p.get_x() + p.get_width()/2, height+3, height, ha = 'center', size=10)
    ax.set_ylim(-5, 3000)