
import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

let wfsSource = null;
let wfsLayer = null;

function makeFilter() {
  let filter = "";

  // 각 클릭할 수 있는 것들 모두 챙겨오기(여기서 지역은 제외되었음)
  const field01 = document.getElementById("field01");
  const field02 = document.getElementById("field02");
  const field03 = document.getElementById("field03");
  const field04 = document.getElementById("field04");
  const run01 = document.getElementById("run01");
  const run02 = document.getElementById("run02");
  const animal01 = document.getElementById("animal01");
  const animal02 = document.getElementById("animal02");
  const animal03 = document.getElementById("animal03");
  const braz01 = document.getElementById("braz01");
  const braz02 = document.getElementById("braz02");
  const braz03 = document.getElementById("braz03");

  // 운영여부에 조건이 있으면 열기 (를 붙임
  // ||는 or 연산자를 의미, run01이나 run02가 체크되면 괄호를 열어라
  if ((true == run01.checked) || (true == run02.checked))
    // {
    //   if (0 < filter.length)
    //     filter += " and "

    filter += "(";
  // }

  if (true == run01.checked) {
    // 체크박스별 값을 찾을 수 있도록 해당 조건을 명시
    filter = filter + "managestatus='운영'"
  }

  if (true == run02.checked) {
    // charAt은 문자열에서 지정된 위치에 존재하는 문자를 찾아서 반환하는 함수
    // filter의 마지막 문자열(length-1)이 "("가 아니면 or을 붙이고 다음 조건을 결합
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "managestatus='휴장'"
  }

  // 운영여부에 조건이 있으면 닫기 )를 붙임
  if ((true == run01.checked) || (true == run02.checked))
    filter += ")"


  // 운영시설에 조건이 있으면 열기 (를 붙임.
  if ((true == field01.checked) || (true == field02.checked) || (true == field03.checked) || (true == field04.checked))
    // 운영여부에도 조건이 있고 운영시설에도 조건이 있으면 둘다 만족해야 하므로 and 
    if (0 < filter.length)
      filter += " and "

  filter += "(";

  if (true == field01.checked) {
    filter = filter + "induty01=1"
  }

  if (true == field02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty02=1"
  }

  if (true == field03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty03=1"
  }

  if (true == field04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty04=1"
  }

  // 운영시설에 조건이 있으면 닫기 )를 붙임
  if ((true == field01.checked) || (true == field02.checked) || (true == field03.checked) || (true == field04.checked))
    filter += ")"


  // 애완견 동반여부에 조건이 있으면 열기 (를 붙임
  if ((true == animal01.checked) || (true == animal02.checked) || (true == animal03.checked)) {
    if (0 < filter.length)
      filter += " and "

    filter += "(";
  }

  if (true == animal01.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "animalcmgcl='가능'"
  }

  if (true == animal02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "animalcmgcl='가능(소형견)'"
  }

  if (true == animal03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "animalcmgcl='불가능'"
  }

  // 애완견 동반여부에 조건이 있으면 닫기 )를 붙임
  if ((true == animal01.checked) || (true == animal02.checked) || (true == animal03.checked))
    filter += ")";

  // 조리대 여부에 조건이 있으면 열기 (를 붙임
  if ((true == braz01.checked) || (true == braz02.checked) || (true == braz03.checked)) {
    if (0 < filter.length)
      filter += " and "

    filter += "(";
  }

  if (true == braz01.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "brazierco='개별'"
  }

  if (true == braz02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "brazierco='공동취사장'"
  }

  if (true == braz03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "brazierco='불가'"
  }

  // 조리대 여부에 조건이 있으면 닫기 )를 붙임
  if ((true == braz01.checked) || (true == braz02.checked) || (true == braz03.checked))
    filter += ")";


  console.log("filter=" + filter)

  return filter;
}


function makeWFSSource() {
  wfsSource = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilter())
      }
    );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");


wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});

const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });

// 각 값들의 변화가 있는지 확인
// 변화가 있으면 makeWFSSource 함수를 호출
document.getElementById('field01').onchange = () => {
  makeWFSSource();
}

document.getElementById('field02').onchange = () => {
  makeWFSSource();
}

document.getElementById('field03').onchange = () => {
  makeWFSSource();
}

document.getElementById('field04').onchange = () => {
  makeWFSSource();
}

document.getElementById('run01').onchange = () => {
  makeWFSSource();
}

document.getElementById('run02').onchange = () => {
  makeWFSSource();
}

document.getElementById('animal01').onchange = () => {
  makeWFSSource();
}

document.getElementById('animal02').onchange = () => {
  makeWFSSource();
}

document.getElementById('animal03').onchange = () => {
  makeWFSSource();
}
document.getElementById('braz01').onchange = () => {
  makeWFSSource();
}

document.getElementById('braz02').onchange = () => {
  makeWFSSource();
}

document.getElementById('braz03').onchange = () => {
  makeWFSSource();
}

