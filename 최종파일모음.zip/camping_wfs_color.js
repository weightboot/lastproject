// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';


// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

const wfsSource = new VectorSource({
  format: new GeoJSON(),
  url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=CampWS:v_campinfo7&outputFormat=application/json")
});

const wfsLayer = new VectorLayer({
  source: wfsSource,
  // style: {
  //   'stroke-width': 0.75,
  //   'stroke-color': 'white',
  //   'fill-color': 'rgba(100,100,100,0.7)',
  // },
  style: new Style({
    // point 레이어를 어떻게(원, 세모, 네모 등) 나타낼지 설정
    // 색상은 rgba 또는 16진수 형식(# FFA07A) 등으로 표기
    // a는 alpha 값으로 0에 가까울수록 투명해짐
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    // line 레이어를 어떻게 나타낼지 설정
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    // polygone 레이어를 어떻게 나타낼지 설정
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});


const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });