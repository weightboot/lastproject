# inDuty, theme의 열값을 다중 행으로 분리

import csv

inDuty=pd.read_csv("inDuty.csv") 
theme=pd.read_csv("theme.csv")


def makeBridge(openFilePath, column_index, saveFilePath):
    
    # csv 파일 읽음
    f = open(openFilePath, encoding='utf-8') 
    data = csv.reader(f) 
    header = next(data)
    
    result = list()
    
    for item in data:
        ID = item[0] # ID
        brData = item[1] # 브리지로 만들 데이터
        
        list_br_data = brData.split(',')
        
        for brData in list_br_data:
            curLine = list() 
            curLine.append(ID) 
            curLine.append(brData)
            
            if (brData):
                result.append(curLine)
    
    f.close()
    
    print(result)
    
    fw = open(saveFilePath, "w", encoding='utf-8', newline='') 
    writer = csv.writer(fw) 
    writer.writerows(result) 
    fw.close()
    
## induty 
makeBridge(r'inDuty.csv', 1, "BridgeInDuty.csv")   

## theme 
makeBridge(r'theme.csv', 1, "BridgeTheme.csv")   