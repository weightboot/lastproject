
import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

let wfsSource = null;
let wfsLayer = null;

function makeFilter() {
  let filter = "";

  // 각 클릭할 수 있는 것들 모두 챙겨오기(여기서 지역은 제외되었음)
  const owner01 = document.getElementById("owner01");
  const owner02 = document.getElementById("owner02");
  const owner03 = document.getElementById("owner03");
  const owner04 = document.getElementById("owner04");
  const owner05 = document.getElementById("owner05");
  const owner06 = document.getElementById("owner06");
  const owner07 = document.getElementById("owner07");
  const owner08 = document.getElementById("owner08");
  const owner09 = document.getElementById("owner09");
  const owner10 = document.getElementById("owner10");
  const people01 = document.getElementById("people01");
  const people02 = document.getElementById("people02");
  const people03 = document.getElementById("people03");
  const people04 = document.getElementById("people04");
  const people05 = document.getElementById("people05");
  const people06 = document.getElementById("people06");
  const age01 = document.getElementById("age01");
  const age02 = document.getElementById("age02");
  const age03 = document.getElementById("age03");
  const age04 = document.getElementById("age04");
  const age05 = document.getElementById("age05");
  const age06 = document.getElementById("age06");
  const age07 = document.getElementById("age07");
  const jimok01 = document.getElementById("jimok01");
  const jimok02 = document.getElementById("jimok02");
  const jimok03 = document.getElementById("jimok03");
  const jimok04 = document.getElementById("jimok04");
  const jimok05 = document.getElementById("jimok05");
  const jimok06 = document.getElementById("jimok06");
  const jimok07 = document.getElementById("jimok07");
  const jimok08 = document.getElementById("jimok08");
  const jimok09 = document.getElementById("jimok09");
  const jimok10 = document.getElementById("jimok10");
  const jimok11 = document.getElementById("jimok11");
  const jimok12 = document.getElementById("jimok012");
  const jimok13 = document.getElementById("jimok13");
  const jimok14 = document.getElementById("jimok14");
  const jimok15 = document.getElementById("jimok15");
  const jimok16 = document.getElementById("jimok016");
  const jimok17 = document.getElementById("jimok17");
  const jimok18 = document.getElementById("jimok18");
  const jimok19 = document.getElementById("jimok19");
  const jimok20 = document.getElementById("jimok20");
  const jimok21 = document.getElementById("jimok21");

  //소유자에 조건이 있으면 열기 (를 붙임.
  if ((true == owner01.checked) || (true == owner02.checked) || (true == owner03.checked) || (true == owner04.checked) || (true == owner05.checked) || (true == owner06.checked) || (true == owner07.checked) || (true == owner08.checked) || (true == owner09.checked) || (true == owner10.checked))

    filter += "(";
  if (true == owner01.checked) {
    filter = filter + "owner='개인'"
  }

  if (true == owner02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='국유지'"
  }


  if (true == owner03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='군유지'"
  }

  if (true == owner04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='시, 도유지'"
  }

  if (true == owner05.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='법인'"
  }

  if (true == owner06.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='기타단체'"
  }

  if (true == owner07.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='외국인, 외국공공기관'"
  }

  if (true == owner08.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='일본인, 창씨명등'"
  }

  if (true == owner09.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='종교단체'"
  }

  if (true == owner10.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "owner='종중'"
  }
  // 소유자에 조건이 있으면 닫기 )를 붙임
  if ((true == owner01.checked) || (true == owner02.checked) || (true == owner03.checked) || (true == owner04.checked) || (true == owner05.checked) || (true == owner06.checked) || (true == owner07.checked) || (true == owner08.checked) || (true == owner09.checked) || (true == owner10.checked))
    filter += ")"


  // 공유인수에 조건이 있으면 열기 (를 붙임.
  if ((true == people01.checked) || (true == people02.checked) || (true == people03.checked) || (true == people04.checked) || (true == people05.checked) || (true == people06.checked))

    if (0 < filter.length)
      filter += " and "

  filter += "(";

  if (true == people01.checked) {
    filter = filter + "people < 20"
  }

  if (true == people02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "people >= 21 and people < 40"
  }

  if (true == people03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "people >= 41 and people < 60"
  }

  if (true == people04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "people >= 61 and people < 80"
  }
  if (true == people05.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "people >= 81 and people < 100"
  }
  if (true == people06.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "people >= 101"
  }

  // 소유자수에 조건이 있으면 닫기 )를 붙임
  if ((true == people01.checked) || (true == people02.checked) || (true == people03.checked) || (true == people04.checked) || (true == people05.checked) || (true == people06.checked))
    filter += ")"

  // 연령에 조건이 있으면 열기 (를 붙임.
  if ((true == age01.checked) || (true == age02.checked) || (true == age03.checked) || (true == age04.checked) || (true == age05.checked) || (true == age06.checked)|| (true == age07.checked))

    if (0 < filter.length)
      filter += " and "

  filter += "(";

  if (true == age01.checked) {
    filter = filter + "age='10세미만'"
  }

  if (true == age02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age='10대'"
  }

  if (true == age03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age='20대'"
  }

  if (true == age04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age='30대'"
  }
  if (true == age05.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age='40대'"
  }
  if (true == age06.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age='50대'"
  }
  if (true == age07.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "age in ('60대',  '70대', '80대',  '90대',  '100세이상')"
  }

  // 운영시설에 조건이 있으면 닫기 )를 붙임
  if ((true == age01.checked) || (true == age02.checked) || (true == age03.checked) || (true == age04.checked) || (true == age05.checked) || (true == age06.checked)|| (true == age07.checked))
    filter += ")"

  // 애완견 동반여부에 조건이 있으면 열기 (를 붙임
  if ((true == jimok01.checked) || (true == jimok02.checked) || (true == jimok03.checked) || (true == jimok04.checked) || (true == jimok05.checked) || (true == jimok06.checked) || (true == jimok07.checked) || (true == jimok08.checked) || (true == jimok09.checked) || (true == jimok10.checked) || (true == jimok11.checked) || (true == jimok12.checked) || (true == jimok13.checked) || (true == jimok14.checked) || (true == jimok15.checked) || (true == jimok16.checked) || (true == jimok17.checked) || (true == jimok18.checked) || (true == jimok19.checked) || (true == jimok20.checked) || (true == jimok21.checked)) {
    if (0 < filter.length)
      filter += " and "

    filter += "(";
  }

  if (true == jimok01.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok01='공원'"
  }

  if (true == jimok02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok02='공장용지'"
  }

  if (true == jimok03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok03='구거'"
  }
  if (true == jimok04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok04='답'"
  }

  if (true == jimok05.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok05='대'"
  }

  if (true == jimok06.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok06='도로'"
  }

  if (true == jimok07.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok07='묘지'"
  }

  if (true == jimok08.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok08='수도용지'"
  }
  if (true == jimok09.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok09='유지'"
  }
  if (true == jimok10.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok10='임야'"
  }
  if (true == jimok11.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok11='잡종지'"
  }

  if (true == jimok12.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok12='전'"
  }

  if (true == jimok13.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok13='제방'"
  }
  if (true == jimok14.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok14='종교용지'"
  }
  if (true == jimok15.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok15='주유소용지'"
  }
  if (true == jimok16.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok16='주차장'"
  }

  if (true == jimok17.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok17='창고용지'"
  }

  if (true == jimok18.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok18='철도용지'"
  }

  if (true == jimok19.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok19='체육용지'"
  }

  if (true == jimok20.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok20='하천'"
  }

  if (true == jimok21.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "jimok21='학교용지'"
  }
  // 애완견 동반여부에 조건이 있으면 닫기 )를 붙임
  if ((true == jimok01.checked) || (true == jimok02.checked) || (true == jimok03.checked) || (true == jimok04.checked) || (true == jimok05.checked) || (true == jimok06.checked) || (true == jimok07.checked) || (true == jimok08.checked) || (true == jimok09.checked) || (true == jimok10.checked) || (true == jimok11.checked) || (true == jimok12.checked) || (true == jimok13.checked) || (true == jimok14.checked) || (true == jimok15.checked) || (true == jimok16.checked) || (true == jimok17.checked) || (true == jimok18.checked) || (true == jimok19.checked) || (true == jimok20.checked) || (true == jimok21.checked))
    filter += ")";


  console.log("filter=" + filter)

  return filter;
}

function makeWFSSource() {
  wfsSource = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/cadaWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=cadaWS:v_cadajijuk&outputFormat=application/json&CQL_FILTER=" + makeFilter())
      }
    );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");


wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(17, 30, 108, 1.0)',
      width: 0.8
    }),
    fill: new Fill({
      color: 'rgba(100, 149, 237, 0.4)'
    })
  })

});

const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14145233, 4508571],
        // 지도 확대 레벨 설정
        zoom: 13
      })
  });

// 각 값들의 변화가 있는지 확인 //
document.getElementById('owner01').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner02').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner03').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner04').onchange = () => {
  makeWFSSource();
}
document.getElementById('owner05').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner06').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner07').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner08').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner09').onchange = () => {
  makeWFSSource();
}

document.getElementById('owner10').onchange = () => {
  makeWFSSource();
}

document.getElementById('people01').onchange = () => {
  makeWFSSource();
}

document.getElementById('people02').onchange = () => {
  makeWFSSource();
}

document.getElementById('people03').onchange = () => {
  makeWFSSource();
}

document.getElementById('people04').onchange = () => {
  makeWFSSource();
}
document.getElementById('people05').onchange = () => {
  makeWFSSource();
}

document.getElementById('people06').onchange = () => {
  makeWFSSource();
}

document.getElementById('age01').onchange = () => {
  makeWFSSource();
}

document.getElementById('age02').onchange = () => {
  makeWFSSource();
}

document.getElementById('age03').onchange = () => {
  makeWFSSource();
}

document.getElementById('age04').onchange = () => {
  makeWFSSource();
}
document.getElementById('age05').onchange = () => {
  makeWFSSource();
}

document.getElementById('age06').onchange = () => {
  makeWFSSource();
}

document.getElementById('age07').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok01').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok02').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok03').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok04').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok05').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok06').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok07').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok08').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok09').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok10').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok11').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok12').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok13').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok14').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok15').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok16').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok17').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok18').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok19').onchange = () => {
  makeWFSSource();
}

document.getElementById('jimok20').onchange = () => {
  makeWFSSource();
}
document.getElementById('jimok21').onchange = () => {
  makeWFSSource();
}

