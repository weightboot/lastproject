// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

// wfsLayer와 wfsSource라는 이름의 변수를 하나 생성
// var, const, let의 차이를 알아두면 좋을 듯
var wfsLayer;
var wfsSource;

// CQL 필터 만드는 함수 추가
// method라는 매개변수가 입력되도록 만들어진 함수
// 함수를 선정할 때 사용한 변수를 매개변수(parameter) 또는 인자라 함
function makeFilter(method) {
  let filter = "";

  if ('sido01' == method)
    // in은 or의 의미와 같음
    filter = "donm in ('서울시', '인천시', '경기도')"

  else if ('sido02' == method)
    filter = "donm in ('대전시', '충청남도', '충청북도', '세종시')";

  else if ('sido03' == method)
    filter = "donm in ('강원도')";

  else if ('sido04' == method)
    filter = "donm in ('대구시', '경상북도')";

  else if ('sido05' == method)
    filter = "donm in ('부산시', '울산시', '경상남도')";

  else if ('sido06' == method)
    filter = "donm in ('전라북도')";

  else if ('sido07' == method)
    filter = "donm in ('전라남도', '광주시')";

  else if ('sido08' == method)
    filter = "donm in ('제주도')";

  else if ('induty01' == method)
    filter = "induty01 = 1";

  else if ('induty02' == method)
    filter = "induty02 = 1";

  else if ('induty03' == method)
    filter = "induty03 = 1";

  else if ('induty04' == method)
    filter = "induty04 = 1";

  else if ('theme01' == method)
    filter = "theme01 = 1";

  else if ('theme02' == method)
    filter = "theme02 = 1";

  else if ('theme03' == method)
    filter = "theme03 = 1";

  else if ('theme04' == method)
    filter = "theme04 = 1";

  else if ('theme05' == method)
    filter = "theme05 = 1";

  else if ('theme06' == method)
    filter = "theme06 = 1";

  else if ('theme07' == method)
    filter = "theme07 = 1";

  else if ('theme08' == method)
    filter = "theme08 = 1";

  else if ('theme09' == method)
    filter = "theme09 = 1";

  else if ('theme10' == method)
    filter = "theme10 = 1";

  else if ('theme11' == method)
    filter = "theme11 = 1";

  else if ('theme12' == method)
    filter = "theme12 = 1";

  return filter;
}

// method라는 매개변수가 입력되도록 만들어진 함수
// url에서 위에서 만들어진 makeFilter(method)를 받아와야함 
function makeWFSSource(method) {
  wfsSource = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilter(method))
      }
    );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");

wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});

const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });


// index 파일에서 명명된 id를 클릭할 때 함수를 실행(또는 호출)하도록 설정
// getElementById는 태그에 있는 id 속성을 사용하여 해당 태그에 접근하여 하고 싶은 작업을 할 때 쓰는 함수
// 해당 id가 없는 경우 null 에러가 발생
document.getElementById('sido01').onclick = () => {
  // 클릭됐다는 것을 단순히 보여주기 위해 설정
  console.log('sido01 clicked');
  // sido01은 인수(전달인자)로 makeWFSSource 함수를 실행할 때 method 부분에 전달됨
  makeWFSSource('sido01');
}

document.getElementById('sido02').onclick = () => {
  console.log('sido02 clicked');
  makeWFSSource('sido02');
}

document.getElementById('sido03').onclick = () => {
  console.log('sido03 clicked');
  makeWFSSource('sido03');
}

document.getElementById('sido04').onclick = () => {
  console.log('sido04 clicked');
  makeWFSSource('sido04');
}

document.getElementById('sido05').onclick = () => {
  console.log('sido05 clicked');
  makeWFSSource('sido05');
}

document.getElementById('sido06').onclick = () => {
  console.log('sido06 clicked');
  makeWFSSource('sido06');
}

document.getElementById('sido07').onclick = () => {
  console.log('sido07 clicked');
  makeWFSSource('sido07');
}

document.getElementById('sido08').onclick = () => {
  console.log('sido08 clicked');
  makeWFSSource('sido08');
}

document.getElementById('induty01').onclick = () => {
  console.log('induty01 clicked');
  makeWFSSource('induty01');
}

document.getElementById('induty02').onclick = () => {
  console.log('induty02 clicked');
  makeWFSSource('induty02');
}

document.getElementById('induty03').onclick = () => {
  console.log('induty03 clicked');
  makeWFSSource('induty03');
}

document.getElementById('induty04').onclick = () => {
  console.log('induty04 clicked');
  makeWFSSource('induty04');
}

document.getElementById('theme01').onclick = () => {
  console.log('theme01 clicked');
  makeWFSSource('theme01');
}

document.getElementById('theme02').onclick = () => {
  console.log('theme02 clicked');
  makeWFSSource('theme02');
}

document.getElementById('theme03').onclick = () => {
  console.log('theme03 clicked');
  makeWFSSource('theme03');
}

document.getElementById('theme04').onclick = () => {
  console.log('theme04 clicked');
  makeWFSSource('theme04');
}

document.getElementById('theme05').onclick = () => {
  console.log('theme05 clicked');
  makeWFSSource('theme05');
}

document.getElementById('theme06').onclick = () => {
  console.log('theme06 clicked');
  makeWFSSource('theme06');
}

document.getElementById('theme07').onclick = () => {
  console.log('theme07 clicked');
  makeWFSSource('theme07');
}

document.getElementById('theme08').onclick = () => {
  console.log('theme08 clicked');
  makeWFSSource('theme08');
}

document.getElementById('theme09').onclick = () => {
  console.log('theme09 clicked');
  makeWFSSource('theme09');
}

document.getElementById('theme10').onclick = () => {
  console.log('theme10 clicked');
  makeWFSSource('theme10');
}

document.getElementById('theme11').onclick = () => {
  console.log('theme11 clicked');
  makeWFSSource('theme11');
}

document.getElementById('theme12').onclick = () => {
  console.log('theme12 clicked');
  makeWFSSource('theme12');
}

let wfsSourceClick = null;
let wfsLayerClick = null;

function makeFilterClick() {
  let filter = "";

  // 각 클릭할 수 있는 것들 모두 챙겨오기(여기서 지역은 제외되었음)
  const duty01 = document.getElementById("duty01");
  const duty02 = document.getElementById("duty02");
  const duty03 = document.getElementById("duty03");
  const duty04 = document.getElementById("duty04");
  const thema01 = document.getElementById("thema01");
  const thema02 = document.getElementById("thema02");
  const thema03 = document.getElementById("thema03");
  const thema04 = document.getElementById("thema04");
  const thema05 = document.getElementById("thema05");
  const thema06 = document.getElementById("thema06");
  const thema07 = document.getElementById("thema07");
  const thema08 = document.getElementById("thema08");
  const thema09 = document.getElementById("thema09");
  const thema10 = document.getElementById("thema10");
  const thema11 = document.getElementById("thema11");
  const thema12 = document.getElementById("thema12");

  // 운영시설에 조건이 있으면 열기 (를 붙인다.
  if ((true == induty01.checked) || (true == induty02.checked) || (true == induty03.checked) ||
    (true == induty04.checked))
    filter += "(";

  if (true == induty01.checked) {
    filter = filter + "induty01=1"
  }

  if (true == induty02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty02=1"
  }

  if (true == induty03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty03=1"
  }

  if (true == induty04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "induty04=1"
  }

  // 운영시설에 조건이 있으면 닫기 )를 붙임
  if ((true == induty01.checked) || (true == induty02.checked) || (true == induty03.checked) ||
    (true == induty04.checked))
    filter += ")"


  // 테마에 조건이 있으면 열기 (를 붙임
  if ((true == thema01.checked) || (true == thema02.checked) || (true == thema03.checked) ||
    (true == thema04.checked) || (true == thema05.checked) || (true == thema06.checked) ||
    (true == theme07.checked) || (true == thema08.checked) || (true == theme09.checked) ||
    (true == thema10.checked) || (true == thema11.checked) || (true == thema12.checked)) {
    if (0 < filter.length)
      filter += " and "

    filter += "(";
  }

  if (true == thema01.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema01=1"
  }

  if (true == thema02.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema02=1"
  }

  if (true == thema03.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema03=1"
  }

  if (true == thema04.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema04=1"
  }

  if (true == thema05.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema05=1"
  }

  if (true == thema06.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema06=1"
  }

  if (true == thema07.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema07=1"
  }

  if (true == thema08.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema08=1"
  }

  if (true == thema09.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema09=1"
  }

  if (true == thema10.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema10=1"
  }

  if (true == thema11.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema11=1"
  }

  if (true == thema12.checked) {
    if (filter.charAt(filter.length - 1) != '(')
      filter += " or "
    filter = filter + "thema12=1"
  }



  // 테마에 조건이 있으면 닫기 )를 붙인다.
  if ((true == thema01.checked) || (true == thema02.checked) || (true == thema03.checked) ||
    (true == thema04.checked) || (true == thema05.checked) || (true == thema06.checked) ||
    (true == thema07.checked) || (true == thema08.checked) || (true == thema09.checked) ||
    (true == thema10.checked) || (true == thema11.checked) || (true == thema12.checked))
    filter += ")";

  console.log("filter=" + filter)

  return filter;
}

function makeWFSSourceClick() {
  wfsSourceClick = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/wfs?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=msk:v_campinfo6&outputFormat=application/json&CQL_FILTER=" + makeFilterClick())
      }
    );

  if (null != wfsLayerClick)
    wfsLayerClick.setSource(wfsSourceClick);
};

makeWFSSourceClick();    // 시작하면서 소스를 한 번 생성

wfsLayerClick = new VectorLayer({
  source: wfsSourceClick,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});

const mapClick = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayerClick],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });

// 각 값들의 변화가 있는지 확인 
document.getElementById('duty01').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('duty02').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('duty03').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('duty04').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema01').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema02').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema03').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema04').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema05').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema06').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema07').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema08').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema09').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema10').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema11').onchange = () => {
  makeWFSSourceClick();
}

document.getElementById('thema12').onchange = () => {
  makeWFSSourceClick();
}
