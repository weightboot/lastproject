// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// view와의 상호작용을 위해 
import { Select, defaults } from 'ol/interaction';
import { pointerMove, click } from 'ol/events/condition';

// 팝업창을 위해
import { Overlay } from 'ol';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

let wfsSource = null;
let wfsLayer = null;

// 목록 클릭 시 CQL 필터 만드는 함수 추가 
function makeFilter(method) {
  let filter = "";

  if ('sido01' == method)
    filter = "donm in ('서울시', '인천시', '경기도')"

  else if ('sido02' == method)
    filter = "donm in ('대전시', '충청남도', '충청북도', '세종시')";

  else if ('sido03' == method)
    filter = "donm in ('강원도')";

  else if ('sido04' == method)
    filter = "donm in ('대구시', '경상북도')";

  else if ('sido05' == method)
    filter = "donm in ('부산시', '울산시', '경상남도')";

  else if ('sido06' == method)
    filter = "donm in ('전라북도')";

  else if ('sido07' == method)
    filter = "donm in ('전라남도', '광주시')";

  else if ('sido08' == method)
    filter = "donm in ('제주도')";

  else if ('induty01' == method)
    filter = "induty01 = 1";

  else if ('induty02' == method)
    filter = "induty02 = 1";

  else if ('induty03' == method)
    filter = "induty03 = 1";

  else if ('induty04' == method)
    filter = "induty04 = 1";

  else if ('theme01' == method)
    filter = "theme01 = 1";

  else if ('theme02' == method)
    filter = "theme02 = 1";

  else if ('theme03' == method)
    filter = "theme03 = 1";

  else if ('theme04' == method)
    filter = "theme04 = 1";

  else if ('theme05' == method)
    filter = "theme05 = 1";

  else if ('theme06' == method)
    filter = "theme06 = 1";

  else if ('theme07' == method)
    filter = "theme07 = 1";

  else if ('theme08' == method)
    filter = "theme08 = 1";

  else if ('theme09' == method)
    filter = "theme09 = 1";

  else if ('theme10' == method)
    filter = "theme10 = 1";

  else if ('theme11' == method)
    filter = "theme11 = 1";

  else if ('theme12' == method)
    filter = "theme12 = 1";

  return filter;
}
function makeWFSSource(method) {
  wfsSource = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilter(method))
      }
    );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");

// 테이블에서 통합검색 시 CQL 필터 만드는 함수 추가
// 목록 클릭과 통합 검색 시 makefilter를 만드는 방식이 다르므로 함수를 별도로 설정
function makeFilterSearch() {
  let filterSearch = "";

  // 각 클릭할 수 있는 것들 모두 챙겨오기(여기서 지역은 제외되었음)
  const run01 = document.getElementById("run01");
  const run02 = document.getElementById("run02");
  const field01 = document.getElementById("field01");
  const field02 = document.getElementById("field02");
  const field03 = document.getElementById("field03");
  const field04 = document.getElementById("field04");
  const animal01 = document.getElementById("animal01");
  const animal02 = document.getElementById("animal02");
  const animal03 = document.getElementById("animal03");
  const braz01 = document.getElementById("braz01");
  const braz02 = document.getElementById("braz02");
  const braz03 = document.getElementById("braz03");

  // filter도 filtersearch로 변경
  //운영여부에 조건이 있으면 열기 (를 붙임.
  if ((true == run01.checked) || (true == run02.checked))
    filterSearch += "(";


  if (true == run01.checked) {
    filterSearch = filterSearch + "managestatus='운영'"
  }

  if (true == run02.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "managestatus='휴장'"
  }

  // 운영여부에 조건이 있으면 닫기 )를 붙임
  if ((true == run01.checked) || (true == run02.checked))
    filterSearch += ")"


  // 운영시설에 조건이 있으면 열기 (를 붙임.
  if ((true == field01.checked) || (true == field02.checked) || (true == field03.checked) || (true == field04.checked)) {

    if (0 < filterSearch.length)
      filterSearch += " and "

    filterSearch += "(";
  }
  if (true == field01.checked) {
    filterSearch = filterSearch + "induty01=1"
  }

  if (true == field02.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "induty02=1"
  }

  if (true == field03.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "induty03=1"
  }

  if (true == field04.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "induty04=1"
  }

  // 운영시설에 조건이 있으면 닫기 )를 붙임
  if ((true == field01.checked) || (true == field02.checked) || (true == field03.checked) || (true == field04.checked))
    filterSearch += ")"


  // 애완견 동반여부에 조건이 있으면 열기 (를 붙임
  if ((true == animal01.checked) || (true == animal02.checked) || (true == animal03.checked)) {
    if (0 < filterSearch.length)
      filterSearch += " and "

    filterSearch += "(";
  }

  if (true == animal01.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "animalcmgcl='가능'"
  }

  if (true == animal02.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "animalcmgcl='가능(소형견)'"
  }

  if (true == animal03.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "animalcmgcl='불가능'"
  }

  // 애완견 동반여부에 조건이 있으면 닫기 )를 붙임
  if ((true == animal01.checked) || (true == animal02.checked) || (true == animal03.checked))
    filterSearch += ")";

  // 조리대 여부에 조건이 있으면 열기 (를 붙임
  if ((true == braz01.checked) || (true == braz02.checked) || (true == braz03.checked)) {
    if (0 < filterSearch.length)
      filterSearch += " and "

    filterSearch += "(";
  }

  if (true == braz01.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "brazierco='개별'"
  }

  if (true == braz02.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "brazierco='공동취사장'"
  }

  if (true == braz03.checked) {
    if (filterSearch.charAt(filterSearch.length - 1) != '(')
      filterSearch += " or "
    filterSearch = filterSearch + "brazierco='불가'"
  }

  // 조리대 여부에 조건이 있으면 닫기 )를 붙임
  if ((true == braz01.checked) || (true == braz02.checked) || (true == braz03.checked))
    filterSearch += ")";


  console.log("filter=" + filterSearch)

  // 변경된 filterSearch 결과를 받아옴
  return filterSearch;
}

// filterSearch에 따라서 wfsSource 만들어주는 함수 설정
function makeWFSSourceSearch() {
  wfsSource = new VectorSource
    (
      {
        format: new GeoJSON(),
        url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
          "&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilterSearch())
      }
    );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSourceSearch("");

wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});

// 점에 hover 시 굵게 표시
const mouseHoverSelect = new Select({
  condition: pointerMove,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(221, 51, 51, 1.0)',
        width: 5
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(255, 0, 255, 0.5)'
      })
    }),
    stroke: new Stroke({
      color: 'rgba(0, 0, 255, 1.0)',
      width: 5
    }),
    fill: new Fill({
      color: 'rgba(0, 0, 255, 0.5)'
    })
  })
});

// 점 클릭 시 굵게 표시
const mouseClickSelect = new Select({
  condition: click,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(0, 255, 0, 1.0)',
        width: 8
      }),
      radius: 10,
      fill: new Fill({
        color: 'rgba(255, 0, 0, 1.0)'
      })
    }),
    stroke: new Stroke({
      color: 'rgba(0, 0, 255, 1.0)',
      width: 5
    }),
    fill: new Fill({
      color: 'rgba(0, 0, 255, 0.5)'
    })
  })
});

// popup 창 설정을 위해서 변수 추가
const popup = document.getElementById('popup');

const overlay = new Overlay({
  element: popup,
  autoPan: {
    animation: {
      duration: 250,
    },
  },
});

const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    // 팝업창 띄우기 위해서 overlay 추가
    overlays: [overlay],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      }),
    // 점에 마우스를 댔을 때 hover 기능 추가
    // interactions: defaults().extend([mouseHoverSelect])
    // 점에 마우스를 댔을 때, 클릭했을 때 hover 기능 둘 다 추가
    interactions: defaults().extend([mouseHoverSelect, mouseClickSelect]),
  });

document.getElementById('sido01').onclick = () => {
  console.log('sido01 clicked');
  makeWFSSource('sido01');
}

document.getElementById('sido02').onclick = () => {
  console.log('sido02 clicked');
  makeWFSSource('sido02');
}

document.getElementById('sido03').onclick = () => {
  console.log('sido03 clicked');
  makeWFSSource('sido03');
}

document.getElementById('sido04').onclick = () => {
  console.log('sido04 clicked');
  makeWFSSource('sido04');
}

document.getElementById('sido05').onclick = () => {
  console.log('sido05 clicked');
  makeWFSSource('sido05');
}

document.getElementById('sido06').onclick = () => {
  console.log('sido06 clicked');
  makeWFSSource('sido06');
}

document.getElementById('sido07').onclick = () => {
  console.log('sido07 clicked');
  makeWFSSource('sido07');
}

document.getElementById('sido08').onclick = () => {
  console.log('sido08 clicked');
  makeWFSSource('sido08');
}

document.getElementById('induty01').onclick = () => {
  console.log('induty01 clicked');
  makeWFSSource('induty01');
}

document.getElementById('induty02').onclick = () => {
  console.log('induty02 clicked');
  makeWFSSource('induty02');
}

document.getElementById('induty03').onclick = () => {
  console.log('induty03 clicked');
  makeWFSSource('induty03');
}

document.getElementById('induty04').onclick = () => {
  console.log('induty04 clicked');
  makeWFSSource('induty04');
}

document.getElementById('theme01').onclick = () => {
  console.log('theme01 clicked');
  makeWFSSource('theme01');
}

document.getElementById('theme02').onclick = () => {
  console.log('theme02 clicked');
  makeWFSSource('theme02');
}

document.getElementById('theme03').onclick = () => {
  console.log('theme03 clicked');
  makeWFSSource('theme03');
}

document.getElementById('theme04').onclick = () => {
  console.log('theme04 clicked');
  makeWFSSource('theme04');
}

document.getElementById('theme05').onclick = () => {
  console.log('theme05 clicked');
  makeWFSSource('theme05');
}

document.getElementById('theme06').onclick = () => {
  console.log('theme06 clicked');
  makeWFSSource('theme06');
}

document.getElementById('theme07').onclick = () => {
  console.log('theme07 clicked');
  makeWFSSource('theme07');
}

document.getElementById('theme08').onclick = () => {
  console.log('theme08 clicked');
  makeWFSSource('theme08');
}

document.getElementById('theme09').onclick = () => {
  console.log('theme09 clicked');
  makeWFSSource('theme09');
}

document.getElementById('theme10').onclick = () => {
  console.log('theme10 clicked');
  makeWFSSource('theme10');
}

document.getElementById('theme11').onclick = () => {
  console.log('theme11 clicked');
  makeWFSSource('theme11');
}

document.getElementById('theme12').onclick = () => {
  console.log('theme12 clicked');
  makeWFSSource('theme12');
}

// 각 값들의 변화가 있는지 확인 //
document.getElementById('run01').onchange = () => {
  makeWFSSourceSearch();
}
document.getElementById('run02').onchange = () => {
  makeWFSSourceSearch();
}
document.getElementById('field01').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('field02').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('field03').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('field04').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('animal01').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('animal02').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('animal03').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('braz01').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('braz02').onchange = () => {
  makeWFSSourceSearch();
}

document.getElementById('braz03').onchange = () => {
  makeWFSSourceSearch();
}

// 지도 클릭 이벤트. 오버레이를 처리
map.on('click', (e) => {
  //console.log(e);

  // 일단 창을 닫음. 이렇게 하면 자료가 없는 곳을 찍으면 창이 닫히는 효과가 나옴
  overlay.setPosition(undefined);

  // 점찍은 곳의 자료를 찾아냄. geoserver에서는 WFS를 위해 위치 정보 뿐 아니라 메타데이터도 같이 보내고 있음
  map.forEachFeatureAtPixel(e.pixel, (feature, layer) => {
    // point와 같이 넘어온 메타데이터 값을 찾음
    let clickedFeatureID = feature.get('id');
    let clickedFeatureName = feature.get('facltnm');
    let firstimageurl = feature.get('firstimageurl');
    let lineintro = feature.get('lineintro');

    // 메타데이터를 오버레이 하기 위한 div에 적음
    // document.getElementById("info-title").innerHTML = clickedFeatureName;
    document.getElementById("info-title").innerHTML = "[" + clickedFeatureID + "] " + clickedFeatureName;
    document.getElementById("lineintro").innerHTML = lineintro;
    document.getElementById("firstimage").src = firstimageurl;

    // 오버레이 창을 띄움
    overlay.setPosition(e.coordinate);
  })
});