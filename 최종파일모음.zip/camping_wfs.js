// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';


// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";

// const vectorSource = new VectorSource({
//   format: new GeoJSON(),
//   url: function (extent) {
//     return (
//       'https://ahocevar.com/geoserver/wfs?service=WFS&' +
//       'version=1.1.0&request=GetFeature&typename=osm:water_areas&' +
//       'outputFormat=application/json&srsname=EPSG:3857&' +
//       'bbox=' +
//       extent.join(',') +
//       ',EPSG:3857'
//     );
//   },
//   strategy: bboxStrategy,
// });

const wfsSource = new VectorSource({
  format: new GeoJSON(),
  url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=CampWS:v_campinfo7&outputFormat=application/json")
});

const wfsLayer = new VectorLayer({
  source: wfsSource,
  // style: {
  //   'stroke-width': 0.75,
  //   'stroke-color': 'white',
  //   'fill-color': 'rgba(100,100,100,0.7)',
  // },
});

// const key = 'Get your own API key at https://www.maptiler.com/cloud/';
// const attributions =
//   '<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> ' +
//   '<a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>';

// const raster = new TileLayer({
//   source: new XYZ({
//     attributions: attributions,
//     url: 'https://api.maptiler.com/maps/satellite/{z}/{x}/{y}.jpg?key=' + key,
//     tileSize: 512,
//     maxZoom: 20,
//   }),
// });

const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });