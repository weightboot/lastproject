# xml-python을 이용한 방법
# 그냥 한 방에 다 다운로드 받고 필요한 열만 뽑아서 테이블 분리할 예정 

import requests
import pandas as pd
from urllib.parse import urlencode, quote_plus, unquote
import xml.etree.ElementTree as ET

url = 'http://apis.data.go.kr/B551011/GoCamping/basedList'
key = unquote('twON8Dt1DG9fuADXSLcnkMf9pp6Whk0T7xtTCqgf3pVJjXOETvY4LegblbnqpJ%2Fj0jiCyBMv2%2FAbIzVjr%2BL0IQ%3D%3D')

params={'numOfRows':'5000', 'pageNo':'1', 'MobileOS': 'ETC', 'MobileApp':'AppTest', 'serviceKey':key}

response = requests.get(url, params)
xmlstring = response.content
tree = ET.ElementTree(ET.fromstring(xmlstring))

camping = []
root = tree.getroot()
for item in root.findall('./body/items/item'):
    camping0=[]
    for child in item:
        if child.tag == 'contentId':
            camping0.append(child.text)
        if child.tag == 'facltNm':
            camping0.append(child.text)
        if child.tag == 'lineIntro':
            camping0.append(child.text)
        if child.tag == 'intro':
            camping0.append(child.text)
        if child.tag == 'manageSttus':
            camping0.append(child.text)
        if child.tag == 'featureNm':
            camping0.append(child.text)
        if child.tag == 'induty':
            camping0.append(child.text)
        if child.tag == 'doNm':
            camping0.append(child.text)
        if child.tag == 'sigunguNm':
            camping0.append(child.text)
        if child.tag == 'addr1':
            camping0.append(child.text)
        if child.tag == 'mapX':
            camping0.append(child.text)
        if child.tag == 'mapY':
            camping0.append(child.text)
        if child.tag == 'direction':
            camping0.append(child.text)
        if child.tag == 'tel':
            camping0.append(child.text)
        if child.tag == 'homepage':
            camping0.append(child.text)
        if child.tag == 'resveUrl':
            camping0.append(child.text)
        if child.tag == 'gnrlSiteCo':
            camping0.append(child.text)
        if child.tag == 'autoSiteCo':
            camping0.append(child.text)
        if child.tag == 'glampSiteCo':
            camping0.append(child.text)
        if child.tag == 'caravSiteCo':
            camping0.append(child.text)
        if child.tag == 'indvdlCaravSiteCo':
            camping0.append(child.text)        
        if child.tag == 'toiletCo':
            camping0.append(child.text)
        if child.tag == 'swrmCo':
            camping0.append(child.text)
        if child.tag == 'wtrplCo':
            camping0.append(child.text)
        if child.tag == 'brazierCl':
            camping0.append(child.text)
        if child.tag == 'themaEnvrnCl':
            camping0.append(child.text)
        if child.tag == 'eqpmnLendCl':
            camping0.append(child.text)
        if child.tag == 'animalCmgCl':
            camping0.append(child.text)
        if child.tag == 'firstImageUrl':
            camping0.append(child.text)
        if child.tag == 'createdtime':
            camping0.append(child.text)
        if child.tag == 'modifiedtime':
            camping0.append(child.text)
    camping.append(camping0)
    camping0.clear
    
headers = ['contentId', 'facltNm', 'lineIntro', 'intro', 'manageSttus', 'featureNm', 'induty', 'doNm', 'sigunguNm', 'addr1', 'mapX', 'mapY', 'direction', 'tel', 
           'homepage', 'resveUrl', 'gnrlSiteCo', 'autoSiteCo', 'glampSiteCo', 'caravSiteCo', 'indvdlCaravSiteCo', 'toiletCo', 'swrmCo', 'wtrplCo', 'brazierCl', 
           'themaEnvrnCl', 'eqpmnLendCl', 'animalCmgCl', 'firstImageUrl', 'createdtime', 'modifiedtime']
camping_df = pd.DataFrame(camping, columns = headers)

# 휴장과 운영을 0과 1로 변환하여 campMeta 파일로 저장
map_manage={'휴장':0, '운영':1}
col=['manageSttus']
camping_df[col] = camping_df[col].applymap(map_manage.get)

camping_df.to_csv(r"campMeta.csv", index=False)

# 필요한 칼럼만 선택해서 테이블 분리
## campInfo 테이블 생성
campInfo = camping_df.drop(['induty', 'mapX', 'mapY', 'toiletCo', 'swrmCo', 'wtrplCo', 'brazierCl', 'themaEnvrnCl'], axis=1)

## inDuty 테이블 생성
induty = camping_df.iloc[:, [0, 6]]

## theme 테이블 생성
theme = camping_df.iloc[:, [0, 25]]

## facility 테이블 생성
facility = camping_df.iloc[:, [0, 21, 22, 23, 24]]

## 결과물 저장
campInfo.to_csv("campInfo.csv", index=False)
induty.to_csv("inDuty.csv", index=False)
theme.to_csv("theme.csv", index=False)
facility.to_csv("facility.csv", index=False)