# inDuty, theme에서 유니크 값 추출하는 방법

import pandas as pd

inDuty=pd.read_csv("inDuty.csv") 
theme=pd.read_csv("theme.csv")


def getUnique(openFilePath, column_name, saveFilePath):
    
    data = pd.read_csv(openFilePath, keep_default_na=False)
    
    allInDuty = ""
    
    ## induty를 리스트로 생성
    allDutyList = data[column_name].tolist()
    
    ## 리스트를 다 연결해 하나의 문자열로 생성
    for item in allDutyList:
        if 0 < len(item.strip()):
            allInDuty += item.strip() + ","
            
    ## 하나의 문자열을 ,로 나눠 다시 문자열 리스트로 생성
    allDutyList2 = allInDuty.split(",")
    
    ## list에서 unique한 값만 찾아냄
    allDutyList3 = set(allDutyList2)
    
    ## 데이터 프레임으로 변환
    df = pd.DataFrame(allDutyList3)
    print(df)
    
    ## CSV 파일로 저장
    df.to_csv(saveFilePath, index=False)
    
## induty 뽑아내기
getUnique(r'inDuty.csv', 'induty', 'inDutyUnique.csv')

## theme 뽑아내기
getUnique(r'theme.csv', 'themaEnvrnCl', 'themeUnique.csv')