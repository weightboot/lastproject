// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";


// CQL 필터 만드는 함수 추가
function makeFilter() {
  let filter = "";
  filter = "induty03=1" //글램핑이 있는 곳
  return filter;
}

// makefilter를 만들어주지 않고 직접 입력해도 됨
// 예를 들어 CQL_FILTER=makeFilter() 대신 CQL_FILTER="induty03=1"로 해도 됨
const wfsSource = new VectorSource({
  // CQL Filter 추가
  format: new GeoJSON(),
  url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilter())
});

const wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

});


const osmLayer = new TileLayer({
  source: new OSM()
});

const map = new Map
  ({
    // target: document.getElementById('map'),
    target: 'map',
    layers: [osmLayer, wfsLayer],
    view: new View
      ({
        // 지도 중심점 설정
        center: [14270476, 4300535],
        // 지도 확대 레벨 설정
        zoom: 7
      })
  });