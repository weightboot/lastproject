// OpenLayers > Examples > WFS
// GeoServer에 있는 camping을 벡터파일로 서비스 후 꾸미기

import './style.css';
import { Map, View } from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';

// geoserver에서 WFS 방식으로 가져오기 위해
import { Vector as VectorLayer } from 'ol/layer';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Style } from 'ol/style';
import { Circle } from 'ol/style';
import { Stroke } from 'ol/style';
import { Fill } from 'ol/style';

// url을 변수로 빼서 따로 설정해 줘도 됨
const g_url = "http://localhost:42888";


// // CQL 필터 만드는 함수 추가
// function makeFilter()
// {
//     let filter="";
//     filter ="induty03=1" //글램핑이 있는 곳
//     return filter;
// }

var wfsLayer;
var wfsSource;


// CQL 필터 만드는 함수 추가
function makeFilter(method)
{
    let filter="";

    if ('sido01' == method)
      filter ="donm in ('서울시', '인천시', '경기도')"

    else if ('sido02' == method)
      filter ="donm in ('대전시', '충청남도', '충청북도', '세종시')";

    /*
    filter ="donm in ('강원도')";
    filter ="donm in ('대구시', '경상북도')";
    filter ="donm in ('부산시', '울산시', '경상남도')";
    */
    return filter;
}
function makeWFSSource(method)
{
  wfsSource = new VectorSource
  (
    {
      format: new GeoJSON(),
      url: encodeURI(g_url + "/geoserver/CampWS/ows?service=WFS&version=1.0.0&request=GetFeature" +
            "&typeName=CampWS:v_campinfo7&outputFormat=application/json&CQL_FILTER=" + makeFilter(method))
    }
  );

  if (null != wfsLayer)
    wfsLayer.setSource(wfsSource);
};

makeWFSSource("");


wfsLayer = new VectorLayer({
  source: wfsSource,
  style: new Style({
    image: new Circle({
      stroke: new Stroke({
        color: 'rgba(255, 221, 235, 1.0)',
        width: 1,
      }),
      radius: 3,
      fill: new Fill({
        color: 'rgba(250, 0, 101, 0.5)',
      })
    }),
    stroke: new Stroke({
      color: 'rgba(250, 0, 101, 1.0)',
      width: 2
    }),
    fill: new Fill({
      color: 'rgba(250, 0, 101, 0.5)'
    })
  })

  });


  const osmLayer = new TileLayer({
    source: new OSM()
  });

  const map = new Map
    ({
      // target: document.getElementById('map'),
      target: 'map',
      layers: [osmLayer, wfsLayer],
      view: new View
        ({
          // 지도 중심점 설정
          center: [14270476, 4300535],
          // 지도 확대 레벨 설정
          zoom: 7
        })
    });

    document.getElementById('sido01').onclick = ()=>
      {
        console.log('sido01 clicked');
        makeWFSSource('sido01');
      }

      document.getElementById('sido02').onclick = ()=>
        {
          console.log('sido02 clicked');
          makeWFSSource('sido02');
        }